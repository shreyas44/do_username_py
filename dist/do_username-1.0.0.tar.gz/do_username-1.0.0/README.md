# do_username_py

A DigitalOcean-community-themed username generator - the Python version.

[Check this out, it's the original and actually used by someone.](https://github.com/MattIPv4/do_username/)
