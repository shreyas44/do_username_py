# do_username_py

A DigitalOcean-community-themed username generator - the Python version.

[Check this out, it's the original and actually used by someone.](https://github.com/MattIPv4/do_username/)

### Usage

Run `pip3 install do_username` to install the package

After installing, run `do_username` to generate a random username or `do_username <max_characters>` to generate a username with max character.
